""" Keras implementation of Telefonica's 1D CNN model
for customer churn prediction. This python code is used
to train the neural net in Watson Machine Learning Service. """

import keras
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers import Dropout
from keras.layers.convolutional import Conv1D
from keras.layers.convolutional import MaxPooling1D
from keras.optimizers import SGD
from keras.utils import to_categorical
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
import os
from os import environ
from keras.callbacks import TensorBoard
import pandas as pd
import numpy as np

#Read data from Object Cloud Storage
input_data_folder = os.environ["DATA_DIR"]

data = open(os.path.join(input_data_folder,"Train_Oversampled.csv"))
df = pd.read_csv(data)

X_data = df.iloc[ : , 0:66].values
y = df.iloc[ : , 67].values
#Reshape data to tensor format
X = X_data.reshape(X_data.shape[0], X_data.shape[1], 1)

#Define the model
model = Sequential()
model.add(Conv1D(64, 3, input_shape=testX.shape[1:3], activation='relu'))
model.add(Dropout(0.5))
model.add(Conv1D(filters=64, kernel_size=3, activation='relu'))
model.add(Dropout(0.5))
model.add(MaxPooling1D(2))
model.add(Flatten())
model.add(Dense(1, activation='sigmoid'))
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy','binary_crossentropy'])

#Train the model
print("starting to train model...")
model.fit(X, y, batch_size=64, epochs=300,validation_split=0.2, verbose=2)
print("model training completed...")

#Save the model
output_model_folder = os.environ["RESULT_DIR"]
output_model_path = os.path.join(output_model_folder,"model")
model.save(output_model_path)